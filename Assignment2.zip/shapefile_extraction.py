# This code uses the following variables:
# polygonFile: input polygon file (e.g. file with countries)
# polygonField: name of field of the input polygon file to query on (e.g. 'NAME')
# polygonValue: value to query polygonField for (e.g. 'El Salvador')
# pointFile: input point file (e.g. file with points of interest)
# pointField: name of field of the input point file to query on (e.g. 'shop')
# pointValue: value to query pointField for (e.g. 'supermarket'); if this variable has the value None, all features with something in pointField will be included
# outputFile: name of the output shapefile to produce
 
import arcpy

def extract_points_within_polygon(polygonFile, polygonField, polygonValue, pointFile, pointField, pointValue, outputFile):
    try:   
        # select target polygon from polygon file
        polygonQuery = f"{polygonField} = '{polygonValue}'"  # query string
        arcpy.MakeFeatureLayer_management(polygonFile,"polygonLayer", polygonQuery)  # produce layer based on query string
        
        # select target points from point file
        if pointValue:   # not None, so the query string needs to use pointValue
            pointQuery = f"{pointField} = '{pointValue}'"
        else:            # pointValue is None, so the query string aks for entries that are not NULL and not the empty string
            pointQuery = f"{pointField} IS NOT NULL AND {pointField} <> ''"
        arcpy.MakeFeatureLayer_management(pointFile,"pointLayer", pointQuery)        # produce layer based on query string
        
        # select only points of interest in point layer that are within the target polygon
        arcpy.SelectLayerByLocation_management("pointLayer", "WITHIN", "polygonLayer")
        
        # write selection to output file
        arcpy.CopyFeatures_management("pointLayer", outputFile)
        
        # clean up layers
        arcpy.Delete_management("polygonLayer")
        arcpy.Delete_management("pointLayer")

        return True, f"Extraction successful: {arcpy.GetCount_management(outputFile)} features written to {outputFile}"
    
    except Exception as e:
        return False, f"An error occurred: {str(e)}"
    

def importArcpyIfAvailable():
    try: # test whether we can import arcpy
        import arcpy
    except:
        return False
    return True