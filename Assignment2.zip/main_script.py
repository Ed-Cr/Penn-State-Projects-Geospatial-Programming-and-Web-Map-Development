import os, sys, time
import arcpy

from PyQt6.QtWidgets import QApplication, QMainWindow, QStyle, QFileDialog, QDialog, QMessageBox, QSizePolicy
from PyQt6.QtGui import QStandardItemModel, QStandardItem,  QDoubleValidator, QIntValidator
from PyQt6.QtCore import QVariant
from PyQt6.QtCore import Qt

from PyQt6.QtWebEngineWidgets import QWebEngineView as WebMapWidget
 
import gui_mainwindow

import shapefile_extraction

# functions for map widgets
def openFileDialog(parent, title, fileType):
    """
    Opens a file dialog to select a file.
    
    :param parent: The parent widget for the dialog.
    :param title: The title of the dialog.
    :param fileType: The type of file to select (e.g., "Shapefile (*.shp)").
    :return: The selected file path or None if no file was selected.
    """
    options = QFileDialog.Option.DontUseNativeDialog
    fileName, _ = QFileDialog.getOpenFileName(parent, title, "", fileType, options=options)
    return fileName if fileName else None

def populate_poi_combobox():
    poi_path = ui.lineEdit.text()
    if not poi_path or not arcpy.Exists(poi_path):
        QMessageBox.warning(MainWindow, "Warning", "Please select a valid file of points first.")
        return
    try:
        poi_field = "shop"
        poi_values = set()

        with arcpy.da.SearchCursor(poi_path, [poi_field]) as cursor:
            for row in cursor:
                poi_values.add(row[0])
        ui.comboBox_2.clear()
        ui.comboBox_2.addItems(sorted(poi_values))
    except Exception as e:
        QMessageBox.critical(MainWindow, "Error", f"An error occurred while populating the combobox: {str(e)}")

def select_poi_shapefile():
    # Opens a file dialog to select a shapefile. Resturns the selected shapefile path or None if no file was selected
    fileName, _ = QFileDialog.getOpenFileName(MainWindow, "Select Shapefile", "", "Shapefile (*.shp)")
    if fileName:
        ui.lineEdit.setText(fileName)
        populate_poi_combobox()
    return openFileDialog(MainWindow, "Select Shapefile", "Shapefile (*.shp)")

def populate_country_combobox():
    # Populates the country combobox with country names from the selected shapefile
    shapefile_path = ui.lineEdit_2.text()
    if not shapefile_path or not arcpy.Exists(shapefile_path):
        QMessageBox.warning(MainWindow, "Warning", "Please select a valid shapefile of countries first.")
        QMessageBox.warning(MainWindow, "Warning", "Please select a shapefile of countries that have a 'NAME' field then try again.")
        return

    try:
        name_field = "NAME"
        name_values = set()

        with arcpy.da.SearchCursor(shapefile_path, [name_field]) as cursor:
            for row in cursor:
                name_values.add(row[0])

        ui.comboBox.clear()
        ui.comboBox.addItems(sorted(name_values))

    except Exception as e:
        QMessageBox.critical(MainWindow, "Error", f"An error occurred while populating the combobox: {str(e)}")

def select_country_shapefile():
    # Opens a file dialog to select a shapefile for countries. Returns the selected shapefile path or None if no file was selected
    fileName, _ = QFileDialog.getOpenFileName(MainWindow, "Select Country shapefile", "", "Shapefile (*.shp)")
    if fileName:
        ui.lineEdit_2.setText(fileName)
        populate_country_combobox()

def select_output_shapefile():
    fileName, _ = QFileDialog.getSaveFileName(MainWindow, "Save Output Shapefile", "", "Shapefile (*.shp)")
    if fileName:
        if not fileName.endswith(".shp"):
            fileName += ".shp"
        ui.lineEdit_3.setText(fileName)

def run_extraction():
    poi_shapefile = ui.lineEdit.text()
    country_shapefile = ui.lineEdit_2.text()
    output_shapefile = ui.lineEdit_3.text()
    country_name = ui.comboBox.currentText()
    include_all_shops = ui.checkBox.isChecked()
    # getting a list of the comboBox_2/POIs values. 
    if include_all_shops:
        shop_type = None
    else:
        shop_type = ui.comboBox_2.currentText()
        if not shop_type or shop_type.strip() == "":
            QMessageBox.warning(MainWindow, "Missing Selection", "Please select a POI type or click the 'Check box to include all shop POIs'")
            return
        
    # validating paths for input files
    if not (poi_shapefile and country_shapefile and output_shapefile):
        QMessageBox.warning(MainWindow, "Missing Input", "Plese fill in all input and output file paths.")
        return
    try:
        success, message = shapefile_extraction.extract_points_within_polygon(
            polygonFile = country_shapefile,
            polygonField = "NAME",
            polygonValue = country_name,
            pointFile = poi_shapefile,
            pointField = "shop",
            pointValue = shop_type,
            outputFile = output_shapefile
        )
        if success:
            QMessageBox.information(MainWindow,  message, "Shapefile extraction completed successfully!")
        else:
            QMessageBox.warning(MainWindow,"No Features Extracted", message)
    except Exception as e:
        QMessageBox.information(MainWindow, "Error", f"Extraction failed:\n{str(e)}")

def clear_fields():
    ui.lineEdit.clear()
    ui.lineEdit_2.clear()
    ui.lineEdit_3.clear()
    ui.comboBox.clear()
    ui.comboBox_2.clear()
    ui.checkBox.setChecked(False)

### ---- SEPERATOR BETWEEN FUNCTIONS AND SCRIPT --- ###
if __name__ == "__main__":

    ### 1. CREATE APP AND MAIN WINDOW
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet("QToolButton { border: none; }")

    MainWindow = QMainWindow()
    ui = gui_mainwindow.Ui_MainWindow()
    ui.setupUi(MainWindow)

    ui.toolButton.clicked.connect(select_poi_shapefile)
    ui.toolButton_2.clicked.connect(select_country_shapefile)
    ui.toolButton_3.clicked.connect(select_output_shapefile)
    # ui.comboBox.addItems(["El Salvador", "Honduras", "Nicaragua", "Costa Rica", "Panama", "Belize", "Guatemala"])  # Example country names
    # ui.comboBox_2.addItems(["supermarket", "restaurant", "hospital", "school"])  # Example point types

    ui.actionExit.triggered.connect(MainWindow.close)


    # Placeholder for the webmap widget
    '''
    createShapefileDialog = QDialog(MainWindow)
    createShapefileDialog_ui = gui_mainwindow.Ui_Dialog()

    # Set up the web map widget

    web_map_widget = WebMapWidget()
    web_map_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
    ui.gridLayout_2.addWidget(web_map_widget, 0, 0, 1, 4)
    '''
    ### 2. CONNECT SIGNALS AND SLOTS



    ### 3. INITIALIZE GLOBAL VARIABLES
    ''' Need to create global variables for:
    The input polygon shapefile path

    The field and value to filter the polygon shapefile

    The input point shapefile path

    The field and value to filter the point shapefile

    The output shapefile path

    '''
    shapefile_extractionHandler = {
        "polygonFile": ui.lineEdit_2.text(),
        "polygonField": "NAME",  # Default field for polygon shapefile, can be changed in the UI
        "pointFile": ui.lineEdit.text(),
        "pointField": "shop",  # Default field for point shapefile, can be changed in the UI
        "outputFile": ui.lineEdit_3.text(),
        "polygonValue": ui.comboBox.currentText(),
        "pointValue": ui.comboBox_2.currentText() if ui.comboBox_2.currentText() else None,  # If no value is selected, use None
        "allPoints": ui.checkBox.isChecked(),
    }

    # runs the shapfile_extraction tool
    ui.pushButton.clicked.connect(run_extraction)

    # clear all inputs with the cancel button
    ui.pushButton_2.clicked.connect(clear_fields)

    result = [] # global variable for storing query results as list of dictionaries
    arcValidLayers = {} # dictionary mapping layer names to layer objects





    ### 4. TEST AVAILABILITY OF ARCPY
    arcpyAvailable = shapefile_extraction.importArcpyIfAvailable()
    if not arcpyAvailable:
        QMessageBox.critical(MainWindow, "Error", "ArcPy is not available. Please ensure ArcGIS is installed and configured correctly.")
        sys.exit(1)

    ### 5. RUN APP
    MainWindow.show()
    
    sys.exit(app.exec())
